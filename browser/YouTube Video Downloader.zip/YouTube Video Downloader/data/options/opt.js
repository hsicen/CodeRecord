var manifest = chrome.runtime.getManifest();
window.location.href = "http://addoncrop.com/console/YouTube_Downloader/Options/opt.php?version="+manifest.version+"&id=" + chrome.runtime.id;